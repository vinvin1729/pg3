package com.example.pg3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    BlankFragment f1;
    BlankFragment2 f2;
    int c=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        f1 = new BlankFragment();
        f2 = new BlankFragment2();
        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();
        ft.replace(R.id.fl,f1);
        ft.commit();
        c=1;
    }
    public  void SWITCHFRG(View view){
        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();
        if(c==1){
            ft.replace(R.id.fl,f2);
            c=2;
        }
        else {
            ft.replace(R.id.fl,f1);
            c=1;
        }
        ft.commit();

    }
}